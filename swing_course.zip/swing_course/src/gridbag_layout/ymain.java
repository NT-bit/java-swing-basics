package gridbag_layout;



public class ymain {

	public static void main(String[] args) {
		
		yframe_gb yf = new yframe_gb("yframe title",667,384);
		yf.yshow();

	}

}
