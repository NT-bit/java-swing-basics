package jtable;

import jmenu.yframe_m;

public class ymain {

	public static void main(String[] args) {
		yframe_table yf = new yframe_table("yframe title",500,600);
		yf.yshow();

	}

}
