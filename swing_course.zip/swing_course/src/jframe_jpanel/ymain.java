package jframe_jpanel;



public class ymain {

	public static void main(String[] args) {
		
		yframe_lesson yf = new yframe_lesson("yframe title",500,600);
		yf.yshow();

	}

}
