package absolute_positioning;

import main.yframe;

public class ymain {

	public static void main(String[] args) {
		
		yframe_ap yf = new yframe_ap("yframe title",667,384);
		yf.yshow();		

	}

}
