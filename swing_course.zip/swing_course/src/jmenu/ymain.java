package jmenu;

import jframe_jpanel.yframe_lesson;

public class ymain {

	public static void main(String[] args) {
		yframe_m yf = new yframe_m("yframe title",500,600);
		yf.yshow();

	}

}
