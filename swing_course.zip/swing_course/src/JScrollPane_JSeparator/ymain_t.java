package JScrollPane_JSeparator;

import main.yframe;

public class ymain_t {

	public static void main(String[] args) {
		
		yframe_t yf = new yframe_t("yframe_t",550,400);
		yf.yshow();

	}

}
