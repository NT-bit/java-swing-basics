package form_events;

import main.yframe;

public class ymain {

	public static void main(String[] args) {
		
		yframe_fe yf = new yframe_fe("form events",500,600);
		yf.yshow();
	}

}
