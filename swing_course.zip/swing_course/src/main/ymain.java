package main;

public class ymain {

	public static void main(String[] args) {
		
		yframe yf = new yframe("yframe title",500,600);
		yf.yshow();
	}

}
