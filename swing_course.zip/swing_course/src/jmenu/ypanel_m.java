package jmenu;

import javax.swing.JPanel;

public class ypanel_m extends JPanel {

}
