package jframe_jpanel;

import java.awt.Color;
import javax.swing.JPanel;


public class ypanel_lesson extends JPanel {

	
	public ypanel_lesson() {
		super();
		setSize( 500, 500 );//set banel size
		setBackground(Color.DARK_GRAY);//set panel background color
	
	}//end constructor
	
	
	
	
}//end ypanel
