package save_to_file;



public class ymain {

	public static void main(String[] args) {
		yframe_sf yf = new yframe_sf("yframe title",500,600);
		yf.yshow();
	}

}
