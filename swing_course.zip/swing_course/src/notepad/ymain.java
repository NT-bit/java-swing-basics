package notepad;



public class ymain {

	public static void main(String[] args) {
		
		yframe_np yf = new yframe_np("yframe title",667, 364);
		yf.yshow();

	}

}
